package org.spring.config;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

public class SecurityInitilizer extends AbstractSecurityWebApplicationInitializer  {
	
}
